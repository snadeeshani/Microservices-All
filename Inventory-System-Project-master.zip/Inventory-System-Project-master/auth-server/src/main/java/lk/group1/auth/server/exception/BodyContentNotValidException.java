package lk.group1.auth.server.exception;

public class BodyContentNotValidException extends RuntimeException {
    public BodyContentNotValidException(String message) {
        super(message);
    }
}
