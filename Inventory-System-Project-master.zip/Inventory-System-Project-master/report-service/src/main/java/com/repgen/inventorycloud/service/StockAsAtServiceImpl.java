package com.repgen.inventorycloud.service;

public class StockAsAtServiceImpl {

}
