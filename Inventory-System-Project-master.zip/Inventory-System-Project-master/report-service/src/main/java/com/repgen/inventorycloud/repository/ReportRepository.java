package com.repgen.inventorycloud.repository;

public interface ReportRepository {

}
