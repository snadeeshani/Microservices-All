package com.repgen.inventorycloud.service;

public interface OnDemandService {

}
