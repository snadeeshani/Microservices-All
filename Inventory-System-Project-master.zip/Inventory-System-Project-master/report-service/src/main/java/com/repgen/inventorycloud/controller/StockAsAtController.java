package com.repgen.inventorycloud.controller;

public class StockAsAtController {

}
