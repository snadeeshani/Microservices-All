package com.repgen.inventorycloud.modal;

public class CriticalItemsList {

	String itemName;
	String bName;
	Integer criticalValue;
	String bNAme;
	Double que;
	
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public Integer getCriticalValue() {
		return criticalValue;
	}
	public void setCriticalValue(Integer criticalValue) {
		this.criticalValue = criticalValue;
	}
	public String getbNAme() {
		return bNAme;
	}
	public void setbNAme(String bNAme) {
		this.bNAme = bNAme;
	}
	public Double getQue() {
		return que;
	}
	public void setQue(Double que) {
		this.que = que;
	}

}
