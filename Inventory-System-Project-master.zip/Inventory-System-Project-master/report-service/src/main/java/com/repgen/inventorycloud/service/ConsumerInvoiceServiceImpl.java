package com.repgen.inventorycloud.service;

public class ConsumerInvoiceServiceImpl {

}
