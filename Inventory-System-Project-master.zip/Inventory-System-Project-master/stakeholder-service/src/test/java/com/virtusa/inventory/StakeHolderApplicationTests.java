package com.virtusa.inventory;

public class StakeHolderApplicationTests {

}
