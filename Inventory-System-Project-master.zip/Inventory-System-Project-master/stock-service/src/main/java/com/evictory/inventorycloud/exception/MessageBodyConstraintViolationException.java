package com.evictory.inventorycloud.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

public class MessageBodyConstraintViolationException extends RuntimeException{

	public MessageBodyConstraintViolationException() {
		super();
		// TODO Auto-generated constructor stub
	}


	public MessageBodyConstraintViolationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
