package com.evictory.inventorycloud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.evictory.inventorycloud.modal.DraftDetails;


public interface DraftDetailsRepository extends JpaRepository<DraftDetails, Integer>{

}
