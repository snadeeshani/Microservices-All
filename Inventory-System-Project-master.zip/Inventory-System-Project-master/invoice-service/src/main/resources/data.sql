insert into reward_point (value,point) VALUES ( 5000.00,0.01);
insert into reward_point (value,point) VALUES ( 6000.00,0.02);
insert into reward_point (value,point) VALUES ( 7000.00,0.03);
insert into reward_point (value,point) VALUES ( 8000.00,0.04);

insert into discount ( discount,price_range) VALUES ( 10.00,5000);
insert into discount ( discount,price_range) VALUES ( 11.00,2000);
insert into discount ( discount,price_range) VALUES ( 14.00,3000);
insert into discount ( discount,price_range) VALUES ( 80.00,4000);

