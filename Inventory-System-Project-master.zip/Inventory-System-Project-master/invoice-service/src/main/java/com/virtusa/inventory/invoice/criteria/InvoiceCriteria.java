package com.virtusa.inventory.invoice.criteria;

import java.util.Date;

public class InvoiceCriteria {
    Date billDate;

    public Date getBillDate() {
        return billDate;
    }

    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }
}
