package com.foodcourt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodcourt.model.StoreType;

public interface StoreTypeRepository extends JpaRepository<StoreType, Integer> {

}
