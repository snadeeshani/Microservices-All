package com.foodcourt.exception;

public class ItemException extends RuntimeException{

	public ItemException(String message) {
		super(message);
	}
	

}
