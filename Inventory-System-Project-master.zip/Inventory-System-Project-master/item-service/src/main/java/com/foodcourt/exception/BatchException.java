package com.foodcourt.exception;

public class BatchException extends RuntimeException {

	public BatchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
